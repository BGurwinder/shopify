---
description: How to run and preview the Shopify theme locally or on Shopify.
---

# How to Run and Check Your Shopify Theme

You have two main ways to preview your theme:

## Option 1: Local Development (Recommended)

This allows you to see changes in real-time as you edit files.

1.  **Install Shopify CLI** (if not already installed):

    - **Node.js** is required.
    - Run: `npm install -g @shopify/cli @shopify/theme`

2.  **Login to Shopify**:

    - Run: `shopify auth login`

3.  **Start the Development Server**:
    - Run: `shopify theme dev --store your-store-name.myshopify.com` shopify theme dev --store omsolutionsbiz.myshopify.com
    - Replace `your-store-name` with your actual store URL.
    - This will open a local preview URL (usually `http://127.0.0.1:9292`).

## Option 2: Upload to Shopify (Manual)

If you don't want to set up the CLI, you can upload the theme directly.

1.  **Zip the Folder**:

    - Compress the contents of `c:\Users\guris\Documents\windsurf\shopify-theme` into a `.zip` file.

2.  **Upload**:

    - Go to your Shopify Admin > **Online Store** > **Themes**.
    - Click **Add theme** > **Upload zip file**.
    - Select your zip file.

3.  **Customize**:
    - Click **Customize** to open the Theme Editor.
    - You can now see your sections (Hero, Product Slider, etc.) and add content.

shopify auth logout
shopify auth login
shopify theme dev --store omsolutionsbiz.myshopify.com
